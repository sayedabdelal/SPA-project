function EditEventPage() {
    return (
        <h1>Edit Event Page</h1>
    )
}
export default EditEventPage;