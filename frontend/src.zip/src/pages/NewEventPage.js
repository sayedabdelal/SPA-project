function NewEventPage() {
    return (
        <h1>New Event Page</h1>
    )
}

export default NewEventPage;