 import { useLoaderData, json } from 'react-router-dom';

import EventsList from '../components/EventsList';

function EventsPage() {
    const data = useLoaderData();

    if(data.isError) {
        return <p>Error: {data.message}</p>;
    }
    const eventData = data.events;
  
  return (
    <>
     
    <EventsList events={eventData} />
    </>
  );
}

export default EventsPage;

// that code excute in a browser not server  but not a react hook in that fun()
export async function loader() {
    const response = await fetch('http://localhost:8080/events');

        if (!response.ok) {
            // return {isError : true , message: 'Could not fetch a events..'}
            // throw new Response(JSON.stringify({message: 'Could not fetch a events.'}), {
            //     status: 500,
            // });
            throw json(
                {message: 'Could not fetch a events..'},
                {
                    status: 500,
                }
            )
        } else {
            // const resData = await response.json();
            // return resData.events;
            return response;
        }
}

/*
useLoaderData you can use it in all commponent except the compnent above in route define
You cannot use useLoaderData in the component that is directly used in the route definition itself.

json .. easy to hangdle code staus
 */